# $SCE INPUT FILE ../data/input!@#().txt
# $SCE OUTPUT FILE ./rubyoutput~ @ # $ % ^ + = { } [ ] ; ,.txt

f = File.open("./rubyoutput~ @ # $ % ^ + = { } [ ] ; ,.txt", "a+")
File.readlines("../data/input!@#().txt").each do |line|
  f.puts line
end
f.puts
f.puts "Created on: #{Time.now.utc}"
f.close
